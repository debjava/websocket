stockticker
-----------

A demo of Java EE 7 websocket.

To run this project:

* Ensure you have java 7 and maven installed
* From project root, run
```
mvn clean org.apache.tomcat.maven:tomcat7-maven-plugin:2.2:run
```
* Open http://localhost:8080/stockticker in your browser

Read the article about this demo on: http://gerrydevstory.com/2014/03/04/stock-ticker-demo-webapp-using-spring-4-websocket/