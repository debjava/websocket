Using WebSockets with Spring, AngularJS and SockJS
===
This application explains how to write a simple Spring web application that communicates through WebSockets by using the spring-websocket framework and the SockJS client library in combination with AngularJS.

* [View the tutorial](http://g00glen00b.be/spring-angular-sockjs)

